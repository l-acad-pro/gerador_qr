#!/bin/bash
sudo apt update
sudo apt install python3-tk -y
echo
echo
echo
read -n 1 -s -r -p "Pressione qualquer tecla para continuar..."
echo